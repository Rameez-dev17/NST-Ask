"use client"

import { useMemo } from "react"

export function JumpingTitle({
  text = "NST-Ask",
  animate = false,
}: {
  text?: string
  animate?: boolean
}) {
  const chars = useMemo(() => text.split(""), [text])
  return (
    <h1 className="text-balance text-5xl md:text-7xl font-bold tracking-tight">
      {chars.map((ch, i) => (
        <span
          key={`${ch}-${i}`}
          className={`inline-block ${animate ? "animate-jump-letter" : ""}`}
          style={animate ? { animationDelay: `${i * 120}ms` } : undefined}
          aria-hidden="true"
        >
          {ch === " " ? "\u00A0" : ch}
        </span>
      ))}
      <span className="sr-only">{text}</span>
    </h1>
  )
}
