"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"

type Phase = "logo-reveal" | "heading" | "collapse"

export default function IntroSplash() {
  const router = useRouter()
  const [phase, setPhase] = useState<Phase>("logo-reveal")

  const TIMING = useMemo(
    () => ({
      logoReveal: 3500, // Extended for dramatic reveal
      headingStay: 4000, // Extended to enjoy the animation
      collapseDuration: 1500,
      exitDelay: 200,
    }),
    [],
  )

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("heading"), TIMING.logoReveal)
    const t2 = setTimeout(() => setPhase("collapse"), TIMING.logoReveal + TIMING.headingStay)
    const t3 = setTimeout(
      () => router.push("/login"),
      TIMING.logoReveal + TIMING.headingStay + TIMING.collapseDuration + TIMING.exitDelay,
    )
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
      clearTimeout(t3)
    }
  }, [TIMING, router])

  const showHeading = phase === "heading"
  const collapsing = phase === "collapse"
  const logoReveal = phase === "logo-reveal"

  return (
    <main
      className={[
        "relative min-h-dvh w-full overflow-hidden transition-colors duration-1000",
        logoReveal
          ? "bg-gradient-to-br from-[oklch(0.2_0.05_240)] via-[oklch(0.15_0.04_220)] to-[oklch(0.18_0.05_200)]"
          : "bg-background",
      ].join(" ")}
      aria-label="Intro"
    >
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        {/* Colorful orbs */}
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={`orb-${i}`}
            className="absolute rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${Math.random() * 8 + 4}px`,
              height: `${Math.random() * 8 + 4}px`,
              background: `radial-gradient(circle, oklch(${0.65 + Math.random() * 0.15} ${0.2 + Math.random() * 0.1} ${180 + Math.random() * 80}) 0%, transparent 70%)`,
              opacity: 0.6,
              animation: `twinkle ${Math.random() * 3 + 2}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
        {/* Floating colorful particles */}
        {Array.from({ length: 25 }).map((_, i) => (
          <div
            key={`particle-${i}`}
            className="absolute rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${Math.random() * 6 + 3}px`,
              height: `${Math.random() * 6 + 3}px`,
              background: `linear-gradient(135deg, oklch(${0.6 + Math.random() * 0.2} ${0.18 + Math.random() * 0.1} ${200 + Math.random() * 40}), oklch(${0.65 + Math.random() * 0.15} ${0.15 + Math.random() * 0.1} ${180 + Math.random() * 60}))`,
              opacity: 0.5,
              animation: `float-particle ${Math.random() * 12 + 18}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
        {/* Large colorful glows */}
        {Array.from({ length: 5 }).map((_, i) => (
          <div
            key={`glow-${i}`}
            className="absolute rounded-full"
            style={{
              left: `${Math.random() * 80 + 10}%`,
              top: `${Math.random() * 80 + 10}%`,
              width: `${Math.random() * 400 + 300}px`,
              height: `${Math.random() * 400 + 300}px`,
              background: `radial-gradient(circle, oklch(${0.6 + Math.random() * 0.15} ${0.2 + Math.random() * 0.08} ${190 + Math.random() * 50} / 0.4) 0%, transparent 70%)`,
              filter: "blur(80px)",
              animation: `color-shift ${Math.random() * 10 + 12}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      {/* Skip button */}
      <button
        onClick={() => router.push("/login")}
        className="absolute right-4 top-4 z-50 rounded-md bg-foreground/10 px-3 py-1.5 text-sm text-foreground/90 backdrop-blur transition hover:bg-foreground/20 focus:outline-none focus:ring-2 focus:ring-primary/40"
      >
        Skip
      </button>

      {/* Center stage wrapper */}
      <div className="relative mx-auto flex min-h-dvh w-full max-w-6xl items-center justify-center px-6">
        <div
          className={[
            "pointer-events-none absolute inset-0 -z-10 transition-opacity duration-1000",
            showHeading && !collapsing ? "opacity-100" : "opacity-0",
          ].join(" ")}
          aria-hidden="true"
        >
          <div className={["water-flow", collapsing ? "scale-out-center" : ""].join(" ")} />
          {/* Additional overlay for depth */}
          <div
            className="absolute inset-0 bg-gradient-to-br from-primary/15 via-transparent to-accent/15"
            style={{
              animation: "water-flow 18s ease infinite reverse",
            }}
          />
        </div>

        <div
          className={[
            "transition-all duration-1000 will-change-transform",
            logoReveal ? "relative z-40 scale-100" : "",
            showHeading ? "fixed left-12 top-12 z-40 scale-[0.6]" : "",
            collapsing ? "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 scale-50" : "",
          ].join(" ")}
          aria-hidden={false}
        >
          <div className="relative">
            {logoReveal && (
              <>
                <div className="absolute inset-0 -z-30 animate-glow-pulse rounded-full blur-[100px] bg-[oklch(0.65_0.2_220/0.6)]" />
                <div
                  className="absolute inset-0 -z-20 animate-glow-pulse rounded-full blur-[80px] bg-[oklch(0.7_0.18_180/0.5)]"
                  style={{ animationDelay: "0.3s" }}
                />
                <div
                  className="absolute inset-0 -z-10 animate-glow-pulse rounded-full blur-[60px] bg-[oklch(0.6_0.15_200/0.4)]"
                  style={{ animationDelay: "0.6s" }}
                />
              </>
            )}
            <Image
              src="/images/newton-logo.png"
              width={logoReveal ? 280 : 100}
              height={logoReveal ? 280 : 100}
              priority
              alt="Newton School of Technology logo"
              className={[
                "rounded-full transition-all duration-1000 relative z-10",
                logoReveal ? "animate-logo-reveal drop-shadow-2xl" : "",
                collapsing ? "animate-scale-down-fade" : "",
              ].join(" ")}
            />
          </div>
          <p
            className={[
              "mt-8 text-center text-xl font-semibold transition-opacity duration-700",
              logoReveal
                ? "animate-fade-in opacity-100 bg-gradient-to-r from-[oklch(0.75_0.2_220)] via-[oklch(0.8_0.18_180)] to-[oklch(0.75_0.2_220)] bg-clip-text text-transparent"
                : "opacity-0",
            ].join(" ")}
            style={{
              textShadow: logoReveal ? "0 0 30px oklch(0.7 0.2 200 / 0.8)" : "none",
              backgroundSize: "200% auto",
              animation: logoReveal ? "text-shimmer 4s linear infinite" : "none",
            }}
          >
            A campus Q&A built for you
          </p>
        </div>

        <div
          className={[
            "flex flex-col items-center text-center transition-all duration-1000",
            showHeading && !collapsing ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8",
            collapsing ? "animate-collapse-to-center" : "",
          ].join(" ")}
          role="group"
          aria-label="Heading"
        >
          <h1
            className="text-balance text-6xl font-bold tracking-tight md:text-8xl"
            style={{
              animation: showHeading && !collapsing ? "text-glow 4s ease-in-out infinite" : "none",
            }}
          >
            <span className="sr-only">Welcome to NST-Ask</span>
            <span
              aria-hidden
              className="relative inline-block bg-gradient-to-r from-[oklch(0.6_0.22_220)] via-[oklch(0.7_0.2_180)] to-[oklch(0.6_0.22_220)] bg-clip-text text-transparent"
              style={{
                backgroundSize: "200% auto",
                animation: showHeading && !collapsing ? "text-shimmer 4s linear infinite" : "none",
              }}
            >
              Welcome to NST-Ask
              <span
                className="absolute inset-x-0 -bottom-4 mx-auto h-1.5 w-full max-w-[18ch] rounded-full bg-gradient-to-r from-transparent via-[oklch(0.65_0.2_220)] to-transparent opacity-90"
                style={{
                  animation: showHeading && !collapsing ? "text-shimmer 3s linear infinite" : "none",
                  backgroundSize: "200% auto",
                }}
              />
            </span>
          </h1>
          <p className="mt-10 text-2xl text-foreground/80 md:text-3xl font-light">
            Find answers faster with a focused academic Q&amp;A space
          </p>
        </div>
      </div>

      <div
        className={[
          "pointer-events-none absolute inset-0 -z-10 bg-background/0 transition-all duration-700",
          collapsing ? "bg-background/90 backdrop-blur-md" : "",
        ].join(" ")}
        aria-hidden="true"
      />
    </main>
  )
}
