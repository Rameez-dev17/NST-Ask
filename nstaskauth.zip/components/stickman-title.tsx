"use client"

import { useEffect, useRef, useState } from "react"

export function StickmanTitle({ title = "NST Ask", duration = 4200 }: { title?: string; duration?: number }) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const [visibleCount, setVisibleCount] = useState(0)
  const letters = title.split("")

  useEffect(() => {
    // Reveal letters evenly across the duration
    const totalSteps = letters.length
    const step = Math.max(1, Math.floor(duration / Math.max(1, totalSteps)))
    const timers: NodeJS.Timeout[] = []
    for (let i = 0; i < totalSteps; i++) {
      timers.push(setTimeout(() => setVisibleCount((v) => Math.max(v, i + 1)), step * (i + 1)))
    }
    return () => timers.forEach(clearTimeout)
  }, [duration, letters.length])

  return (
    <div ref={containerRef} className="relative w-full h-40 md:h-48">
      {/* Ground line */}
      <div className="absolute inset-x-0 bottom-6 h-px bg-white/20" aria-hidden />

      {/* Title letters */}
      <div className="absolute inset-x-0 top-0 flex h-full items-end justify-start gap-2 md:gap-3">
        {letters.map((ch, i) => (
          <span
            key={`${ch}-${i}`}
            className={`text-5xl md:text-7xl font-bold tracking-tight ${
              i < visibleCount ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
            } transition duration-300`}
            aria-hidden={i >= visibleCount}
          >
            {ch === " " ? "\u00A0" : ch}
          </span>
        ))}
      </div>

      {/* Stickman (simple SVG) */}
      <div
        className="absolute bottom-6 left-0 animate-stick-move"
        style={{ animationDuration: `${duration}ms` }}
        aria-hidden
      >
        <svg
          width="56"
          height="80"
          viewBox="0 0 56 80"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="animate-stick-bob"
        >
          {/* head */}
          <circle cx="28" cy="12" r="10" stroke="currentColor" strokeWidth="3" className="text-white" />
          {/* body */}
          <line x1="28" y1="22" x2="28" y2="48" stroke="currentColor" strokeWidth="3" className="text-white" />
          {/* arms */}
          <line x1="28" y1="26" x2="12" y2="36" stroke="currentColor" strokeWidth="3" className="text-white" />
          <line x1="28" y1="26" x2="44" y2="36" stroke="currentColor" strokeWidth="3" className="text-white" />
          {/* legs */}
          <line x1="28" y1="48" x2="14" y2="66" stroke="currentColor" strokeWidth="3" className="text-white" />
          <line x1="28" y1="48" x2="42" y2="66" stroke="currentColor" strokeWidth="3" className="text-white" />
        </svg>
      </div>
    </div>
  )
}
