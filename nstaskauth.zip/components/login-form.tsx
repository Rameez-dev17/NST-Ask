"use client"

import type * as React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function LoginForm({ onSuccess }: { onSuccess?: () => void }) {
  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    console.log("[v0] Sign in clicked")
    onSuccess?.()
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="space-y-2 animate-slide-in-bottom" style={{ animationDelay: "0.1s" }}>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          name="email"
          type="email"
          inputMode="email"
          placeholder="you@example.com"
          autoComplete="email"
          required
          className="transition-all duration-300 focus:shadow-lg focus:shadow-primary/10"
        />
      </div>

      <div className="space-y-2 animate-slide-in-bottom" style={{ animationDelay: "0.2s" }}>
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          name="password"
          type="password"
          placeholder="••••••••"
          autoComplete="current-password"
          required
          className="transition-all duration-300 focus:shadow-lg focus:shadow-primary/10"
        />
      </div>

      <Button
        type="submit"
        className="w-full animate-slide-in-bottom transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
        style={{ animationDelay: "0.3s" }}
      >
        Sign In
      </Button>

      <Button
        type="button"
        variant="secondary"
        className="w-full animate-slide-in-bottom transition-all duration-300 hover:shadow-md"
        style={{ animationDelay: "0.4s" }}
      >
        New here? Sign Up
      </Button>

      <Button
        type="button"
        variant="ghost"
        className="w-full animate-slide-in-bottom transition-all duration-300"
        style={{ animationDelay: "0.5s" }}
      >
        Become a Mentor
      </Button>
    </form>
  )
}
