import IntroSplash from "@/components/intro-splash"

export default function IntroPage() {
  return <IntroSplash />
}
