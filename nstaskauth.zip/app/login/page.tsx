"use client"

import { Suspense, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LoginForm } from "@/components/login-form"
import { JumpingTitle } from "@/components/jumping-title"

export default function LoginPage() {
  const [ignored] = useState(false)

  return (
    <main className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 text-foreground relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div
          className="absolute top-20 left-10 w-2 h-2 rounded-full bg-primary/30 animate-float"
          style={{ animationDelay: "0s" }}
        />
        <div
          className="absolute top-40 right-20 w-3 h-3 rounded-full bg-accent/40 animate-float"
          style={{ animationDelay: "1s" }}
        />
        <div
          className="absolute bottom-32 left-1/4 w-2 h-2 rounded-full bg-primary/20 animate-float"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute top-1/3 right-1/3 w-1.5 h-1.5 rounded-full bg-accent/30 animate-float"
          style={{ animationDelay: "1.5s" }}
        />
      </div>

      <div className="mx-auto w-full max-w-7xl px-6 py-10 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-center">
          <section className="flex flex-col justify-center animate-slide-in-left">
            <JumpingTitle text="NST-Ask" animate={false} />
            <div className="mt-4 space-y-2">
              <p className="text-muted-foreground text-lg md:text-xl font-medium">Ask Freely. Learn Boldly.</p>
              <p className="text-muted-foreground text-base md:text-lg">Where Curiosity Finds Clarity.</p>
            </div>
          </section>

          <section className="flex justify-center md:justify-end animate-slide-in-right">
            <div className="w-full max-w-md">
              <Card className="bg-card text-card-foreground border-primary/20 shadow-lg shadow-primary/5 animate-slide-in-bottom">
                <CardHeader>
                  <CardTitle className="text-2xl bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    Sign in
                  </CardTitle>
                  <CardDescription>
                    Continue to <span className="font-medium text-primary">NST-Ask</span>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Suspense>
                    <LoginForm />
                  </Suspense>
                </CardContent>
              </Card>

              <p className="mt-6 text-center text-xs text-muted-foreground animate-fade-in">
                By continuing, you agree to our Terms of Service and Privacy Policy.
              </p>
            </div>
          </section>
        </div>
      </div>
    </main>
  )
}
